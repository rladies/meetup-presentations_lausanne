#https://github.com/jstockwin/EpiEstimApp/wiki

install.packages("devtools")
library(devtools)
devtools::install_github("jstockwin/EpiEstimApp", ref = "recon-update", force = TRUE)
EpiEstimApp::runEpiEstimApp()
